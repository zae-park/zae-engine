from ._loss import IoU
from ._loss import mIoU
from ._loss import GIoU
from ._loss import cross_entropy
