from .beat import core as peak_segmentation
from .sec10 import core as ecg_classification
